#include "TM4C123GH6PM.h"
#include "hehe.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <math.h>
extern void Delay2ms(void);
// Comparator 0 Initialization
void InitComp0(void) {
  
    // Enable clock for GPIOC and Comparator Module
    SYSCTL->RCGCGPIO |= (1 << 2); //C
    SYSCTL->RCGCACMP |= (1 << 0); //clock for Comparator 0
    __ASM("NOP");
    __ASM("NOP");
    __ASM("NOP");
	
		SYSCTL->RCGCGPIO |= 0x20; //GPIOF
		__ASM("NOP");
		__ASM("NOP");
		__ASM("NOP");
	
		GPIOF->DIR			|= 0x04; //PF2 OP
		GPIOF->AFSEL		&= (0xFFFFFFFB);  
		GPIOF->PCTL			&= 0xFFFFF0FF;  
		GPIOF->AMSEL		=0; 
		GPIOF->DEN			|=0x04; 
	
		GPIOF->DIR			|= 0x08; //PF3 OP
		GPIOF->AFSEL		&= (0xFFFFFFF7);
		GPIOF->PCTL			&= 0xFFFF0FFF;
		GPIOF->AMSEL		=0;
		GPIOF->DEN			|=0x08;
		
    // Configure PC6 and PC7 as analog input pins
    GPIOC->DIR &= ~((1 << 6) | (1 << 7));  // Set PC6, PC7 as input
    GPIOC->AFSEL |= (1 << 6) | (1 << 7);   // Enable alternate functions
    GPIOC->DEN &= ~((1 << 6) | (1 << 7));  // Disable digital functionality
    GPIOC->AMSEL |= (1 << 6) | (1 << 7);   // Enable analog functionality

    // Configure Comparator 0
    COMP->ACREFCTL = 0; 
    COMP->ACCTL0 = (0x0 << 9)|(0x0 << 1)|(0x2 << 2) ;// pf6 +, pf7 -
    COMP->ACINTEN = (1 << 0);   // Enable interrupt for Comparator 0
		COMP->ACMIS = (1 << 0);
	
    NVIC_EN0_R |= (1 << 25);   //interrupt comp0
		  
		
}



void COMP0_Handler(void) {
        // Perform desired action (e.g., toggle an LED or send a message)
	 if (COMP->ACMIS & (1 << 0)) {  // Check if Comparator 0 triggered the interrupt
        COMP->ACMIS = (1 << 0);   // Clear the interrupt flag
	 }

}