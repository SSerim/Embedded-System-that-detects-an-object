//INPUTLARI 1 2 3 OLMALI
//1 KIRMIZI X<50
//2 MAVI 		50<X<75
//3 YESIL		75<X<100,
//KAPATMAK I�IN 123 HARICI HERHANGI BIR DEVER VER


//PF1,2,3 KULLANILIYOR

#include "TM4C123GH6PM.h"

int rgbConfig(int distance){
	
	
	SYSCTL->RCGCGPIO |= 0x20; // turn on bus clock for GPIOF
	
	__ASM("NOP");
	__ASM("NOP");
	__ASM("NOP");

	
	GPIOF->DIR |= 0x0E;
	GPIOF->DEN |= 0x0E;
	
	switch(distance){
		
		case(1):								//closer than 50
			GPIOF->DATA = 0x02;		//RED
			break;
		case(2):								//50 - 75 cm
			GPIOF->DATA = 0x04;		//BLUE
			break;
		case(3):								//75 - 100 cm
			GPIOF->DATA = 0x08;		//GREEN
			break;
		default:								//no object
			GPIOF->DATA &= ~0x0E;		//NO LIGHT
			break;
	};
	return 0;
};