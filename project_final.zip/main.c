#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include "TM4C123GH6PM.h"
#include "Nokia5510_sensor.h"
#include "hehe.h"
#include "rgbConfig.h"
#include "analogComparator.h"
int keypad_flag = 0;
void DeepSleepConfig(void);
void EnterDeepSleep(void);
int deep_sleep_flag = 0;
uint8_t thresh_2[5];
int alkim = 0;
float angle;
int kkk = 0;
float smallest;
	int angle_no;
int counter_a = 0;
float distance = 0;
int interrupt_deneme = 0;
extern void Delay2ms(void);
float distance_trial;
float distance_meas[33];
volatile int *SYS_LOAD = (volatile int*) 0xE000E014;
volatile int *PORTE_OUT = (volatile int*)0x400243FC;	
int step_cont_a = 0x02;
int step_cont_b = 0x10;
volatile int first_step_cnt_forvard = 0;
int first_step_cnt_rvrs = 1024;
int GPTM_trial = 0;
int step_no =0;
int cnt = 5;
int	counted_num5 = 15999;
int dist_no = 0;
    uint8_t thresh_1[5];
int first_number;
int second_number;
float temp_total_thresh;

volatile float total_thresh;
    volatile int *memory_address = (volatile int*)0x20004000;  // Pointer to the memory address
    uint8_t thresh = 0;  // Variable that holds the value to write to memory
extern void keypad(void);  // Declare the assembly entry point
typedef int32_t BMP280_S32_t;
float sicaklik;
int keypad_no = 0;
    uint8_t data[3];
    int32_t adc_T;	uint8_t chip_id;
	uint8_t temp_dene1;
	uint8_t temp_dene2;
	uint8_t temp_dene3;
    int32_t raw_temp;
	int16_t	dig_T1;
	int16_t	dig_T2;
	int16_t	dig_T3;
	int8_t	dig_T1_1;
	int8_t	dig_T1_2;
	int8_t	dig_T2_1;
	int8_t	dig_T2_2;
	int8_t	dig_T3_1;
	int8_t	dig_T3_2;
	int32_t var1, var2, T, t_fine;
	int LM_TH = 0;
	
	
	
	void buzzer_init(int buzz)
	{
	
	SYSCTL->RCGCGPIO |= 0x08; // turn on bus clock for GPIOE
	
	__ASM("NOP");
	__ASM("NOP");
	__ASM("NOP");

	
	GPIOD->DIR |= 0x04;
	GPIOD->DEN |= 0x04;
	
	if (buzz == 0) {
			GPIOD->DATA &= ~(1<<2);
	}
	else if(buzz == 1)
	{
			GPIOD->DATA |= (1<<2);

	}
}
	
	void power_led_init(int LM_TH)
	{
	
	SYSCTL->RCGCGPIO |= 0x10; // turn on bus clock for GPIOE
	
	__ASM("NOP");
	__ASM("NOP");
	__ASM("NOP");

	
	GPIOE->DIR |= 0x20;
	GPIOE->DEN |= 0x20;
	
	if (LM_TH == 0) {
    GPIOE->DATA &= ~0x20; // Clear bit 0 of GPIOF->DATA (Pin 0 turns off)
	} else if (LM_TH == 1) {
    GPIOE->DATA |= 0x20;  // Set bit 0 of GPIOF->DATA (Pin 0 turns on)
	} else {
    GPIOE->DATA &= ~0x20; // Default case: Clear bit 0 (Pin 0 turns off)
	}

	}
	void Delay_MicroSecond(int time){
    int i;
    SYSCTL->RCGCTIMER |= 2;     /* enable clock to Timer Block 1 */
    TIMER1->CTL = 0;            /* disable Timer before initialization */
    TIMER1->CFG = 0x04;         /* 16-bit option */ 
    TIMER1->TAMR = 0x02;        /* periodic mode and down-counter */
    TIMER1->TAILR = 16 - 1;  /* TimerA interval load value reg */
    TIMER1->ICR = 0x1;          /* clear the TimerA timeout flag */
    TIMER1->CTL |= 0x01;        /* enable Timer A after initialization */

    for(i = 0; i < time; i++)
    {
        while ((TIMER1->RIS & 0x1) == 0) ;      /* wait for TimerA timeout flag */
        TIMER1->ICR = 0x1;      /* clear the TimerA timeout flag */
    }
}
void TriggerPulse(void) {
    GPIOC->DATA &= ~0x10;      // Set TRIG low PD7 PIN
    Delay_MicroSecond(20);                // Ensure TRIG is low for 2 ms
    GPIOC->DATA |= 0x10;       // Set TRIG high 
    Delay_MicroSecond(100);               // TRIG high for 100 ms delay For sensor to get trigger effect
    GPIOC->DATA &= ~0x10;      // Set TRIG low
}
float Distance_Measure(){
				volatile uint32_t rise_time = 0, fall_time = 0, pulse_width = 0;
				TriggerPulse();
			
				while ((TIMER2->RIS & 0x04) == 0);
				if(GPIOF->DATA & (1<<4)) /*check if rising edge occurs */
				{
        rise_time = TIMER2->TAR; // Capture time of rising edge
        TIMER2->ICR = 0x04;      // Clear capture event flag

        // Wait for falling edge on ECHO
        while ((TIMER2->RIS & 0x04) == 0);
        fall_time = TIMER2->TAR; // Capture time of falling edge
        TIMER2->ICR = 0x04;      // Clear capture event flag

        // Calculate pulse width
        pulse_width = (fall_time - rise_time)/16;

        // Calculate distance (in mm)
        distance = (pulse_width * 0.34) / 2; // To calculate distance given formula is used.
				}

				return distance;




}	
	void Timer0B_init(void)
	{
	volatile int *NVIC_EN0 = (volatile int*) 0xE000E100;
	volatile int *NVIC_PRI4 = (volatile int*) 0xE000E410;
  volatile int *NVIC_PRI5 = (volatile int *)0xE000E414; // NVIC Priority Register 5
	
	SYSCTL->RCGCTIMER	|=0x01; // Start timer0
	__ASM("NOP");
	__ASM("NOP");
	__ASM("NOP");
    TIMER0->CTL &= ~0x0100;       // Disable Timer0B during setup (clear TBEN bit)
	TIMER0->CFG			=0x04;  //Set 16 bit mode
	TIMER0->TBMR		=0x02; // set to periodic, count down
	TIMER0->TBILR		=0x100; //Set interval load as LOW
	TIMER0->TBPR		=15; // Divide the clock by 16 to get 1us
	TIMER0->IMR			=0x100; //Enable timeout intrrupt	
	
	//Timer0A is interrupt 19
	//Interrupt 16-19 are handled by NVIC register PRI4
	//Interrupt 19 is controlled by bits 31:29 of PRI4
  *NVIC_PRI5 &= ~0x000000E0;    // Clear priority bits for interrupt 20
    *NVIC_PRI5 |= (2 << 5);       // Set priority level 2 (binary `010`)
	//NVIC has to be neabled
	//Interrupts 0-31 are handled by NVIC register EN0
	//Interrupt 19 is controlled by bit 19
	*NVIC_EN0 |=(1 << 20);
	
	//Enable timer
    TIMER0->CTL |= 0x0100;        // Enable Timer0B (set TBEN bit)
	return;
}
	



	void GPTM0_Init(void) {
    // 1. Enable clock for GPTM0 (Timer 0)
    SYSCTL->RCGCTIMER |= 0x10;  // Enable clock to Timer 0 (GPTM0) (Bit 0)
		__ASM("NOP");
    __ASM("NOP");
    __ASM("NOP");
    // 2. Configure GPTM0
    TIMER4->CTL = 0x00;                // Disable GPTM0 before configuration (Clear the control register)
    TIMER4->CFG = 0x00;                // 32-bit timer mode (Standard configuration)
    TIMER4->TAMR = 0x02;               // Periodic mode (0x02: Periodic Timer mode, 0x01: One-shot mode)
    
    // 3. Set the timer's load value to control the frequency of interrupts
    // For example, to set the timer to trigger every 100ms (assuming 16MHz clock):
    TIMER4->TAILR = 1600000 - 1;       // Load value for 100ms interval (1600000 = 16M * 0.1s)

    // 4. Enable the timer interrupt
    TIMER4->IMR |= 0x01;               // Enable interrupt on Timer A timeout (TATOCINT) (Bit 0)

    // 5. Clear any previous interrupt flag
    TIMER4->ICR |= 0x01;               // Clear the interrupt flag before enabling (TATOCINT)

    // 6. Start the timer
    TIMER4->CTL |= 0x01;               // Enable Timer A (TAEN) (Bit 0)

    // 7. Enable the GPTM interrupt in the NVIC
    NVIC->ISER[0] |= (1<<102);      // Enable IRQ for Timer 0 (IRQ number 19, corresponding to 0x00080000)
}

	
	void GPTM4_Handler(void) {
    // Clear the interrupt flag
    TIMER4->ICR |= 0x100;  // Clear the TATOCINT flag
		GPTM_trial = 1;
}
	
	
	
	
		void interrupt_deep_sleep(void){
			SYSCTL->RCGCGPIO |= (1 << 0);   /* Set bit5 of RCGCGPIO to enable clock to PORTF*/
		__ASM("NOP");
    __ASM("NOP");
    __ASM("NOP");
    GPIOA->DIR &= ~(1<<4) ;        /* Set PD2 as input */
    GPIOA->DEN |= (1<<4) ;         /* Enable digital functionality on PD2 */
    GPIOA->AFSEL |= (1<<4);      // Enable alternate function on PF4 0x10

    //GPIOD->IM &= ~(1<<2);         /* Mask interrupt for PD2 during configuration */
    GPIOA->IS &= ~(1<<4) ;         /* Set PD2 as edge-sensitive */
    GPIOA->IBE &= ~(1<<4);        /* Trigger is controlled by IEV */
    GPIOA->IEV |= (1<<4) ;         /* Rising edge trigger */
    GPIOA->ICR |= (1<<4);         /* Clear any prior interrupt */
    GPIOA->IM |= (1<<4) ;          /* Unmask interrupt for PD2 */
    NVIC->ISER[0] |= (1 << 0);    /* Enable IRQ3 (Check your NVIC table for PORTD) */
				
			
			
		}
	void GPIOA_Handler(void)
   {    
	if (GPIOA->RIS & (1 << 4))
		 {  
        GPIOA->ICR = (1 << 4);   
				keypad_flag = 0;
   }
 }

 
		void interrupt_keypad(void){
			SYSCTL->RCGCGPIO |= (1 << 2);   /* Set bit5 of RCGCGPIO to enable clock to PORTF*/
		__ASM("NOP");
    __ASM("NOP");
    __ASM("NOP");
    GPIOC->DIR &= ~(1<<5) ;        /* Set PD2 as input */
    GPIOC->DEN |= (1<<5)			;         /* Enable digital functionality on PD2 */
    GPIOC->AFSEL |= (1<<5);      // Enable alternate function on PF4 0x10

    //GPIOD->IM &= ~(1<<2);         /* Mask interrupt for PD2 during configuration */
    GPIOC->IS &= ~(1<<5) ;         /* Set PD2 as edge-sensitive */
    GPIOC->IBE &= ~(1<<5);        /* Trigger is controlled by IEV */
    GPIOC->IEV |= (1<<5) ;         /* Rising edge trigger */
    GPIOC->ICR |= (1<<5);         /* Clear any prior interrupt */
    GPIOC->IM |= (1<<5) ;          /* Unmask interrupt for PD2 */
    NVIC->ISER[0] |= (1 << 2);    /* Enable IRQ3 (Check your NVIC table for PORTD) */
				
			
			
		}
	void GPIOC_Handler(void)
   {    
	if (GPIOC->RIS & (1 << 5))
		 {  
        GPIOC->ICR = (1 << 5);   
deep_sleep_flag = 1;	
		 }
 }
void GPIO_Init_Sensor(void) {
    //SYSCTL->RCGCGPIO |= 0x20;  // Enable clock to Port F
		
    
		SYSCTL->RCGCGPIO |= 0x04;
		__ASM("NOP");
    __ASM("NOP");
    __ASM("NOP");

    // TRIG pin configuration (PC4)
    GPIOC->DIR |= 0x10;        // Set PC4 as output  
    GPIOC->DEN |= 0x10;        // Enable PC4 as digital pin 
				SYSCTL->RCGCGPIO |= 0x20;
		__ASM("NOP");
    __ASM("NOP");
    __ASM("NOP");
    // ECHO pin configuration (PF4)
    GPIOF->DIR &= ~0x10;       // Set PF4 as input 0x10
    GPIOF->DEN |= 0x10;        // Enable PF4 as digital pin 0x10
    GPIOF->AFSEL |= 0x10;      // Enable alternate function on PF4 0x10
    GPIOF->PCTL &= ~0x0000F000;	//0x0000F000
    GPIOF->PCTL |= 0x000070000; // Configure PB6 as T0CCP0 0x000070000


    Delay_MicroSecond(100);              // Wait to stabilize and avoid first trigger effect from the pin
		
		
}
void Timer0A_Init_Sensor(void) {
    SYSCTL->RCGCTIMER |= 0x04; // Enable clock to Timer0
    __ASM("NOP");              // Allow clock to stabilize
    __ASM("NOP");
    __ASM("NOP");

    TIMER2->CTL &= ~0x01;      // Disable TIMER0A during setup
    TIMER2->CFG = 0x04;        // Configure as 16-bit timer
    TIMER2->TAMR = 0x17;       // Edge Time mode, count up
    TIMER2->CTL |= 0x0C;       // Capture on both edges
    TIMER2->CTL |= 0x01;       // Enable TIMER0A
		
}

void Initialization_step_motor(){


	
SYSCTL->RCGCGPIO |= 0x10;	//0x02 idi
	
__asm("NOP");
__asm("NOP");
__asm("NOP");
	GPIOE->DIR |= 0x1E;    // Set PC4-PC7 as outputs
GPIOE->DEN |= 0x1E;    // Enable digital function for PC4-PC7
GPIOE->DATA &= ~0x1E;  // Clear PC4-PC7 to ensure they start at 0
	
	
	
	
GPIOE->AFSEL &= ~0x1E;  // Disable alternate functions for PC4�PC7


}
volatile int *SYS_CTRL = (volatile int*) 0xE000E010;

void init_systick (void){
volatile int *SYS_BASE = (volatile int*) 0xE000E000;
volatile int *SYS_LOAD = (volatile int*) 0xE000E014;
volatile int *SYS_VAL = (volatile int*) 0xE000E018;
*(SYS_LOAD) = 15999; // Configure load value
*(SYS_VAL) = 15999999; // Clear the timer register by writing to it
*(SYS_CTRL) |= 0x03; //source system bus, interrupt enabled and clock is started
}

void BookExamples(void) {
    int8_t cc = 0x56; // ('V')
    int32_t xx = 100;
    int16_t yy = -100;
    float zz = 3.14159265;

    Nokia5110_Clear();
    Nokia5110_OutString("Book Examples:");
    Nokia5110_SetCursor(0, 1); // Move to the next line
    Nokia5110_OutString("Hello world");
    // Print more details if needed, tailored to fit the LCD size
}


void setRW(uint8_t mode)		//from mode = 0 -----> transmit data , for mode = 1 -----> receive data
{
if (mode == 0){
	I2C3->MSA &= ~(1 << 0);
}
else{
	I2C3->MSA |= (1<<0);
}
}

void writeByte(uint8_t data, uint8_t conds)		//data in 0x00 type, conds (1<<0)|(1<<1) means Start and Run --- conds (1<<0)||(1<<2) means Stop and Run
{
	I2C3->MDR = data;
	I2C3->MCS = conds;
	
	while((I2C3->MCS & (1<<0)) != 0);	//WAIT UNTIL TRANSMISSION IS COMPLETE

	if((I2C3->MCS & (1 << 0)) != 0)		//CHECK FOR ERRORS
	{
	if ((I2C3->MCS & (1 << 4)) == 1)
	{
	//conroller lost, solve it accordingly
	}
	else
	{
	I2C3->MCS = (1<<2);	//Send Stop
		while((I2C3->MCS & (1<<0)) !=0);
	}
	}
}
void init_I2C(void) 
{
SYSCTL->RCGCI2C = (1 << 3);	//ENABLE CLOCK FOR I2C MODULE 0
SYSCTL->RCGCGPIO = ( 1 << 3);//ENABLE CLOCK FOR GPIO PORT B

GPIOD->AFSEL |= (1 << 0) | (1 << 1);	//FOR PORTB2		//SCL
	
GPIOD->DEN |= (1 << 0) | (1 << 1);	//FOR PORTB2
	
GPIOD->ODR |= (1 << 1);

//GPIOD->PCTL = (3 << 16) | (3 << 20);	//For PortB2
    GPIOD->PCTL = (GPIOD->PCTL & ~0x000000FF) | (3 << 0) | (3 << 4); // Configure PD0 and PD1 for I2C2 (AF3)
	
I2C3->MCR = (1 << 4);

I2C3->MTPR = (7 << 0);

I2C3->MSA = (77 << 1);	//Set Slave address ---- Slave address is 0x77 when SD0 of BMP280 connected to the Vcc
}
void writeRegister(uint8_t reg, uint8_t value) {
    I2C3->MSA = (0x77 << 1) | 0; // Set slave address and write mode
    I2C3->MDR |= reg;         // Send register address
    I2C3->MCS = 3;           // Start and run
    while (I2C3->MCS & 1);   // Wait for completion

    I2C3->MDR = value;       // Send data
    I2C3->MCS = 5;           // Run and stop
    while (I2C3->MCS & 1);   // Wait for completion
}
void readRegisters(uint8_t reg, uint8_t *buffer, uint8_t length) {
    I2C3->MSA = (0x77 << 1) | 0; // Set slave address and write mode
    I2C3->MDR = reg;         // Send register address
    I2C3->MCS = 3;           // Start and run
    while (I2C3->MCS & 1);   // Wait for completion

    I2C3->MSA = (0x77 << 1) | 1; // Set slave address and read mode
    for (int i = 0; i < length; i++) {
        I2C3->MCS = (i == length - 1) ? 5 : 9; // Run, stop for last byte
       while (I2C3->MCS & 1);                // Wait for completion
        buffer[i] = I2C3->MDR;               // Read data
    }
}
// Returns temperature in DegC, double precision. Output value of �51.23� equals 51.23 DegC.
// t_fine carries fine temperature as global value
float readTemperature(void) {


    // Read temperature registers
    readRegisters(0xFA, data, 3);

    // Combine data
    adc_T = ((data[0] << 16) | (data[1] << 8) | data[2]) >> 4;

    // Compensate temperature
    return adc_T;
}
void initBMP280(void) {
    // Write to control and config registers
    writeRegister(0xF4, 0x27); // Set osrs_t and power mode
    writeRegister(0xF5, 0xA0); // Set config
}
uint8_t readRegister(uint8_t reg) {
    uint8_t data;

    // Write register address
    I2C3->MSA = (0x77 << 1) | 0; // Slave address with write mode
    I2C3->MDR = reg;             // Register address to read
    I2C3->MCS = 3;               // Start and run
    while (I2C3->MCS & 1);       // Wait for completion

    if (I2C3->MCS & (1 << 1)) {  // Check for error
        return 0;
    }

    // Switch to read mode
    I2C3->MSA = (0x77 << 1) | 1; // Slave address with read mode
    I2C3->MCS = 7;               // Start, run, and stop
    while (I2C3->MCS & 1);       // Wait for completion

    if (I2C3->MCS & (1 << 1)) {  // Check for error
        return 0;
    }

    data = I2C3->MDR;            // Read data
    return data;
}
int32_t meas_temp(void)
{
	chip_id = readRegister(0xD0);
	temp_dene1 = readRegister(0xFA);
	temp_dene2 = readRegister(0xFB);
	temp_dene3 = readRegister(0xFC);
	dig_T1_1 = readRegister(0x88);
	dig_T1_2 = readRegister(0x89);
	dig_T2_1 = readRegister(0x8A);
	dig_T2_2 = readRegister(0x8B);
	dig_T3_1 = readRegister(0x8C);
	dig_T3_2 = readRegister(0x8D);
    // Combine raw temperature data
    raw_temp = ((temp_dene1 << 16) | (temp_dene2 << 8) | temp_dene3) >> 4;
		dig_T1 = ((dig_T1_1) | (dig_T1_2 << 8));
		dig_T2 = ((dig_T2_1) | (dig_T2_2<<8) );
		dig_T3 = ((dig_T3_1) | (dig_T3_2 << 8));
var1 = ((((raw_temp>>3) - (dig_T1<<1))) * (dig_T2)) >> 11;
var2 = (((((raw_temp>>4) - (dig_T1)) * ((raw_temp>>4) - (dig_T1))) >> 12) *
(dig_T3)) >> 14;
t_fine = var1 + var2;
T = (t_fine * 5 + 128) >> 8;
return (float)T;
}

	int a;
		int b;
			int c;
				int d;
volatile float keypad_input_get(void)

{
	Nokia5110_Clear(); // Clear LCD for each iteration
Nokia5110_SetCursor(0, 0); // Set cursor to the start
	Nokia5110_OutString("Enter new threshold:");
keypad_no = 0;
	int k = 0;

	for (keypad_no; keypad_no < 4; keypad_no++)
	{
keypad();
volatile int *memory_address_1 = (volatile int *)0x20004000; // Pointer to memory address
    // Read the value from memory
    thresh_1[k] = *memory_address_1;
		k = k +1;
		thresh = *memory_address_1;
	}
step_cont_a = 0x02;
step_cont_b = 0x10;
first_step_cnt_rvrs = 1024;

	 a = thresh_1[0] -0x30;
	 b = thresh_1[1] - 0x30;
	 c = thresh_1[2] - 0x30;
	 d = thresh_1[3] - 0x30;

first_number = a * 10 + b; // Combine thresh[0] and thresh[1]
second_number = c * 10 + d; // Combine thresh[2] and thresh[3]
total_thresh = a*1000 + b*100 + c*10 +d;
	keypad_flag = 1;
SysTick->CTRL |= 0x03;
	__ASM("NOP");
	__ASM("NOP");
	__ASM("NOP");
return total_thresh;
	}
	

int main()
{
	interrupt_keypad();
	interrupt_deep_sleep();
Delay_MicroSecond(1000000);
//GPTM0_Init();
	init_I2C();
  initBMP280();
	Output_Init(); // Initialize Nokia5110 LCD

	Nokia5110_Clear(); // Clear LCD for each iteration
Nokia5110_SetCursor(0, 0); // Set cursor to the start
	Nokia5110_OutString("BMP Measured:");
Nokia5110_SetCursor(0, 2); // Set cursor to the start
	Nokia5110_OutString("BMP Threshold:");
InitComp0();
DeepSleepConfig();
	/*
rgbConfig(1);
Delay_MicroSecond(200000);
EnterDeepSleep();
	
rgbConfig(2);*/
Initialization_step_motor();
init_systick();
 char thresh_str[6];
temp_total_thresh = keypad_input_get();
sprintf(thresh_str, "%.2f", temp_total_thresh/100); // Format temperature to 2 decimal places
//rgbConfig(1);
        for (int i = 0; i < 1; i++) {

						Nokia5110_SetCursor(0, 4); // Move to the second line
            Nokia5110_OutString(thresh_str); // Display current value
					}
Delay_MicroSecond(300000);
keypad_flag = 1;
//EnterDeepSleep();
EnterDeepSleep();
power_led_init(1);	
//rgbConfig(2);
while(1)
{

		

    // Initialize I2C and BMP280
	Nokia5110_Clear(); // Clear LCD for each iteration
Nokia5110_SetCursor(0, 0); // Set cursor to the start
	Nokia5110_OutString("BMP Measured:");
Nokia5110_SetCursor(0, 2); // Set cursor to the start
	Nokia5110_OutString("BMP Threshold:");

        	sicaklik = meas_temp();
 char temp_str[6];
sprintf(temp_str, "%.2f", sicaklik/100); // Format temperature to 2 decimal places
for (int i = 0; i < 1; i++) {
            Nokia5110_SetCursor(0, 1); // Move to the second line
            Nokia5110_OutString(temp_str); // Display current value
}
 //char thresh_str[6];
//temp_total_thresh = keypad_input_get();

sprintf(thresh_str, "%.2f", temp_total_thresh/100); // Format temperature to 2 decimal places
        for (int i = 0; i < 1; i++) {

						Nokia5110_SetCursor(0, 4); // Move to the second line
            Nokia5110_OutString(thresh_str); // Display current value
					}
				
Delay_MicroSecond(1000000);
	

//bura		
				Delay_MicroSecond(1000000);

//	distance_trial = Distance_Measure(); //in mm
if((first_step_cnt_forvard == 1024) & (first_step_cnt_rvrs == 0))
{
	smallest = distance_meas[0];
for (alkim; alkim<=33;alkim++)
	{
		if(distance_meas[alkim] < smallest)
		{
		smallest = distance_meas[alkim];
		angle_no = alkim;
			angle = (angle_no * 180) / 34;
		}
	}
 // Format temperature to 2 decimal places

/*char ang_str[6];
sprintf(ang_str, "%.2f", angle); // Format temperature to 2 decimal places

for (int i = 0; i < 1; i++) {
            Nokia5110_SetCursor(0, 1); // Move to the second line
            Nokia5110_OutString(ang_str); // Display current value
}
*/
	if(smallest > 1000)
	{
			Nokia5110_Clear(); // Clear LCD for each iteration
Nokia5110_SetCursor(0, 0); // Set cursor to the start
	Nokia5110_OutString("No Object:");
	}
	else
	{
		Nokia5110_Clear(); // Clear LCD for each iteration
Nokia5110_SetCursor(0, 0); // Set cursor to the start
	Nokia5110_OutString("Angle:");
Nokia5110_SetCursor(0, 2); // Set cursor to the start
	Nokia5110_OutString("Distance:");

char dist_str[6];
sprintf(dist_str, "%.2f", smallest); // Format temperature to 2 decimal places
for (int i = 0; i < 1; i++) {
            Nokia5110_SetCursor(0, 3); // Move to the second line
            Nokia5110_OutString(dist_str); // Display current value

}
char ang_str[6];
sprintf(ang_str, "%.2f", angle);
for (int i = 0; i < 1; i++) {
						Nokia5110_SetCursor(0, 1); // Move to the second line
            Nokia5110_OutString(ang_str); // Display current value
}
}
	}
sicaklik = meas_temp();
if(temp_total_thresh < sicaklik)
{
	if ( kkk== 0)
	{
	*(SYS_CTRL) |= 0x03;

	//Timer0B_init();


	kkk = 1;
	step_no = 1;
	dist_no = 1;
	}
	while((first_step_cnt_forvard != 1024) && (first_step_cnt_rvrs != 0)) 
		
	{}

kkk = 1;
step_no = 1;
dist_no = 1;
}
				Delay_MicroSecond(2000000);
if (deep_sleep_flag ==1 )
{
		Nokia5110_Clear(); // Clear LCD for each iteration
Nokia5110_SetCursor(0, 0); // Set cursor to the start
	Nokia5110_OutString("BMP Threshold:");

	
	sprintf(thresh_str, "%.2f", temp_total_thresh/100); // Format temperature to 2 decimal places

	for (int i = 0; i < 1; i++) {
            Nokia5110_SetCursor(0, 1); // Move to the second line
            Nokia5110_OutString(thresh_str); // Display current value
}
EnterDeepSleep();
}
	if (keypad_flag == 0)
	{
SysTick->CTRL &= 0x00010000;
			
	__ASM("NOP");
	__ASM("NOP");
	__ASM("NOP");
		temp_total_thresh = keypad_input_get();
		first_step_cnt_forvard = 0;
		first_step_cnt_rvrs = 1024;
		kkk = 0;
//	SysTick->CTRL |= 0x03;
//	
//	__ASM("NOP");
//	__ASM("NOP");
//	__ASM("NOP");
	}
}
return 0;
}


void TIMER0B_Handler(void) {
	TIMER0->ICR |= 0x100;    // Your interrupt handling code here
	GPIO_Init_Sensor();
Timer0A_Init_Sensor();
	distance_trial = Distance_Measure(); //in mm
}

	void SysTick_Handler(void) {
	volatile int *SYS_CTRL = (volatile int*) 0xE000E010;
		if(first_step_cnt_forvard != 1024)
		{
		if(step_no == 1){
					GPIOE->DATA = step_cont_a | (1 << 5);
			first_step_cnt_forvard ++;
			step_cont_a = step_cont_a * 2;
			if( step_cont_a == 0x20){
				step_cont_a = 0x02;
			}
				
		}
		if((((first_step_cnt_forvard % 32) == 0) && (first_step_cnt_forvard >=32)) || (first_step_cnt_forvard == 1))
		{
*(SYS_CTRL) &= 0x00;
GPIO_Init_Sensor();
Timer0A_Init_Sensor();
distance_trial = Distance_Measure();
distance_meas[counter_a] = distance_trial;
counter_a = counter_a +1;
*(SYS_CTRL) |= 0x03;

		}
	}
		else
		{
			if(first_step_cnt_rvrs)
			{
		if(step_no == 1){
					GPIOE->DATA = step_cont_b | (1 << 5);
			first_step_cnt_rvrs --;
					step_cont_b = step_cont_b / 2;
			if ( step_cont_b == 1) {
			step_cont_b = 0x10;
			}
}
		
		}
	}

}
	
void DeepSleepConfig(void) {
    // Configure power modes for deep sleep
    SYSCTL->DSLPPWRCFG |= SYSCTL_DSLPPWRCFG_SRAMPM_LP;  // Low power mode for SRAM
    SYSCTL->DSLPPWRCFG |= SYSCTL_DSLPPWRCFG_FLASHPM_SLP; // Sleep mode for Flash

    // Configure the clock source during deep sleep
    SYSCTL->DSLPCLKCFG = SYSCTL_DSLPCLKCFG_O_IO;

    // Set the SLEEPDEEP bit in the System Control Block (SCB)
    NVIC_SYS_CTRL_R |= 0x04;
}

void EnterDeepSleep(void) {
    // Wait for interrupt to wake up
		//rgbConfig(0);
//s*(SYS_CTRL) =0X00010000;
	        //COMP->ACMIS = (1 << 0); 
	SysTick->CTRL &= 0x00010000;
	
	__ASM("NOP");
	__ASM("NOP");
	__ASM("NOP");
	deep_sleep_flag = 0;
	DeepSleepConfig();
//	COMP->ACMIS = (1 << 0);
	power_led_init(0);
    __WFI();
	SysTick->CTRL |= 0x03;
	__ASM("NOP");
	__ASM("NOP");
	__ASM("NOP");
		power_led_init(1);
buzzer_init(1);
Delay_MicroSecond(200000);
buzzer_init(0);

}